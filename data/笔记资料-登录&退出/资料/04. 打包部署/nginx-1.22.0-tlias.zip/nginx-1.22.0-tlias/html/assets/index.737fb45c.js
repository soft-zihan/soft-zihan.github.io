import{_ as e}from"./_plugin-vue_export-helper.cdc0426e.js";const r={};function c(n,t){return" \u5B66\u5458\u7BA1\u7406 "}const o=e(r,[["render",c]]);export{o as default};
