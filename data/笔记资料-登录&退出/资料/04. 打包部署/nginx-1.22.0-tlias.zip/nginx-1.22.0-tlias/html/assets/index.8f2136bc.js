import{_ as e}from"./_plugin-vue_export-helper.cdc0426e.js";const r={};function c(n,t){return" \u73ED\u7EA7\u7BA1\u7406 "}const o=e(r,[["render",c]]);export{o as default};
